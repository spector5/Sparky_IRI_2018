package org.usfirst.frc.team384.robot;

public class Constants {
	// Joysticks
	public static final int STICK0 = 0;
	public static final int STICK1 = 1;
	public static final int XAXIS	= 0;
	public static final int YAXIS	= 1;
	public static final int ZAXIS	= 2;
	public static final int ZROTATE	= 3;	// only for Saitek, get rid of for student sticks
	
	// Drivetrain
	public static final int DRIVE_LEFT = 0;
	public static final int DRIVE_RIGHT = 1;
	public static final int DRIVE_ENC_PPR  = 512;	// Talon counts 4 edges * 128 PPR
	public static final double DRIVE_DIST_PER_PULSE = 6.0 * Math.PI / DRIVE_ENC_PPR;
	
	
	// Elevator
	public static final int ENCODER_GROUND = 0; 
	public static final int ENCODER_LOW = 550; 
	public static final int ENCODER_LOWSWITCH = 1200;
	public static final int ENCODER_HISWITCH = 1500; //1100
	public static final int ENCODER_SCALE = 3175;
}

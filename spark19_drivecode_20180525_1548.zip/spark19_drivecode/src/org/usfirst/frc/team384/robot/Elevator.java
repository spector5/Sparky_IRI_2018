package org.usfirst.frc.team384.robot;

import com.ctre.phoenix.motorcontrol.ControlMode;
import com.ctre.phoenix.motorcontrol.FeedbackDevice;
import com.ctre.phoenix.motorcontrol.LimitSwitchNormal;
import com.ctre.phoenix.motorcontrol.LimitSwitchSource;
import com.ctre.phoenix.motorcontrol.NeutralMode;
import com.ctre.phoenix.motorcontrol.can.TalonSRX;

import edu.wpi.first.wpilibj.Solenoid;
//import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;

//import edu.wpi.first.wpilibj.SpeedControllerGroup;

public class Elevator {
	
	// Motors
	private TalonSRX lifterSecondaryMotor = new TalonSRX(9);	// Front motor
	private TalonSRX lifterPrimaryMotor = new TalonSRX(10);		// Rear motor

	// Solenoids
	private Solenoid pto        = new Solenoid(0);
	private Solenoid climber    = new Solenoid(3);
	
	// Define the motors that are slaved as a control group
	//private SpeedControllerGroup lifter = new SpeedControllerGroup(lifterSecondaryMotor, lifterPrimaryMotor);

	public Elevator()	{
		lifterPrimaryMotor.set(ControlMode.PercentOutput, 0);
	    lifterSecondaryMotor.follow(lifterPrimaryMotor);
	    lifterPrimaryMotor.configSelectedFeedbackSensor(FeedbackDevice.QuadEncoder, 0, 10);
	    lifterPrimaryMotor.setSensorPhase(false);
	    lifterPrimaryMotor.setInverted(false);
	    lifterPrimaryMotor.configReverseLimitSwitchSource(LimitSwitchSource.FeedbackConnector, LimitSwitchNormal.NormallyOpen, 0);
	    lifterPrimaryMotor.configForwardLimitSwitchSource(LimitSwitchSource.FeedbackConnector, LimitSwitchNormal.NormallyOpen, 0);
	    lifterPrimaryMotor.overrideLimitSwitchesEnable(true);

	    lifterPrimaryMotor.configOpenloopRamp(0.3, 0);
	    lifterPrimaryMotor.setNeutralMode(NeutralMode.Brake);
	    lifterPrimaryMotor.configOpenloopRamp(0.3, 0);
	    //lifterPrimaryMotor.setNeutralMode(NeutralMode.Brake);

	    lifterPrimaryMotor.configMotionCruiseVelocity(700, 0);
	    lifterPrimaryMotor.configMotionAcceleration(5000, 0);
	    lifterPrimaryMotor.config_kP(0, 6, 10);
	    lifterPrimaryMotor.config_kI(0, 0.0001, 10);
	    lifterPrimaryMotor.config_kD(0, 350, 10);
	}
	
	/*
	 * Initialize encoders
	 */
	public void initializeEncoders()	{
		lifterPrimaryMotor.getSensorCollection().setQuadraturePosition(0, 0);
		lifterPrimaryMotor.setSensorPhase(true);	// runs negative otherwise, due to being mirrored
	}
	
	/*
	 * Get encoder position
	 * 
	 */
	public int getEncoderPosition()	{
		return lifterPrimaryMotor.getSensorCollection().getQuadraturePosition();
	}

	//public double getPosition() {
	    //return lifterPrimaryMotor.getSelectedSensorPosition(0);
	//}

	public double getVelocity() {
	    return lifterPrimaryMotor.getSelectedSensorVelocity(0);
	}

	public boolean getIsElevAtTop() {
	    return lifterPrimaryMotor.getSensorCollection().isFwdLimitSwitchClosed();
	}

	public boolean getIsElevAtBottom() {
	    return lifterPrimaryMotor.getSensorCollection().isRevLimitSwitchClosed();
	}

	/*
	 * Get rid of autonGoTo as it's a copy of goTo, but save the parameters first  
	 */
	
	//public void move(double speed) {
	    //lifterSecondaryMotor.set(ControlMode.PercentOutput, speed);
	  //}

	  // I can probably get rid of this
	  //public void autonGoTo(double height) {
	    //boolean isDescending = (height < getPosition());
	    //if (isDescending) {
	      //if (getPosition() < 400) {
	        //lifterPrimaryMotor.configMotionCruiseVelocity(50, 0);
	        //lifterPrimaryMotor.configMotionAcceleration(500, 0);
	      //} else {
	        //lifterPrimaryMotor.configMotionCruiseVelocity(250, 0);
	        //lifterPrimaryMotor.configMotionAcceleration(1500, 0);
	      //}
	    //} else {
	      //lifterPrimaryMotor.configMotionCruiseVelocity(300, 0);  // 700
	      //lifterPrimaryMotor.configMotionAcceleration(1500, 0);   // 5000
	    //}
	    //lifterPrimaryMotor.set(ControlMode.MotionMagic, height);
	  //}  
	  
	  // This is a duplicate of autonGoTo, can we get rid of above?
	  // The only difference is acceleration and cruise velocity, which can be passed as arguments from Robot.java
	  public void goTo(double height) {
	    boolean isDescending = (height < getEncoderPosition());
	    
	    // Make sure the PTO is set to elevator, I can't believe Bobb didn't do this 
	    shiftToElevate();
	    
	    if (isDescending) {
	      if (getEncoderPosition() < 400) {							// approaching bottom
	        lifterPrimaryMotor.configMotionCruiseVelocity(100, 0);
	        lifterPrimaryMotor.configMotionAcceleration(500, 0);
	      } else {													// not yet approaching bottom
	        lifterPrimaryMotor.configMotionCruiseVelocity(250, 0);
	        lifterPrimaryMotor.configMotionAcceleration(1500, 0);
	      }
	    } else {  // ascending, so punch it
	      lifterPrimaryMotor.configMotionCruiseVelocity(700, 0);  // 700
	      lifterPrimaryMotor.configMotionAcceleration(3500, 0);   // was 5000 before retrofitting #25 chain
	    }
	    lifterPrimaryMotor.set(ControlMode.MotionMagic, height);
	  }
	  
	  
//	  public void goTo(Height height) {
//	    goTo(height.getHeight());
//	  }

	  public void stop() {
	    lifterPrimaryMotor.set(ControlMode.PercentOutput, 0);
	  }
	  
	  public void manualControl(double speed) {
		  shiftToElevate();
		  lifterPrimaryMotor.set(ControlMode.PercentOutput, speed);
		  // Zero out the encoder if bottom prox made
		  if (getIsElevAtBottom())	{
			  lifterPrimaryMotor.getSensorCollection().setQuadraturePosition(0, 0);
		  }
	  }
	  

	  // Raises or lowers the climber arm, based on current state
	  public void climberToggle()	{
		  if(climber.get())	{
			  climber.set(true);
		  } else {
			  climber.set(false);
		  }
	  }
	  
	  public void shiftToElevate() {
		  pto.set(true);
	  }

	  public void shiftToClimb() {
		  pto.set(false);
	  }
}

package org.usfirst.frc.team384.robot;

import com.ctre.phoenix.motorcontrol.NeutralMode;
import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;
import com.kauailabs.navx.frc.AHRS;

import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.SPI;
import edu.wpi.first.wpilibj.SpeedControllerGroup;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;

public class Drivetrain {

	/* Instantiate talon motors */
	private WPI_TalonSRX frontRightMotor = new WPI_TalonSRX(7);
	private WPI_TalonSRX rearRightMotor = new WPI_TalonSRX(8);
	private WPI_TalonSRX frontLeftMotor = new WPI_TalonSRX(5);		// -1.0 to run forward
	private WPI_TalonSRX rearLeftMotor = new WPI_TalonSRX(6);		// -1.0 to run forward

	
	// Define the motors that are slaved as a control group
	private SpeedControllerGroup leftDrivetrain = new SpeedControllerGroup(frontLeftMotor, rearLeftMotor);
	private SpeedControllerGroup rightDrivetrain = new SpeedControllerGroup(frontRightMotor, rearRightMotor);
	
	// Set up differential drive for teleop
	private DifferentialDrive diffDrive = new DifferentialDrive(leftDrivetrain, rightDrivetrain);
	
	private AHRS imu;	// the NavX board
	
	public Drivetrain()	{
		// Initialize the IMU
		try {
			imu = new AHRS(SPI.Port.kMXP);
		} catch (RuntimeException ex) {
			DriverStation.reportError("Error instantiating navX MXP:  " + ex.getMessage(), true);
			
		}
		
	// Do we really need this?
	frontRightMotor.setSafetyEnabled(false);
	frontLeftMotor.setSafetyEnabled(false);
	rearRightMotor.setSafetyEnabled(false);
	rearLeftMotor.setSafetyEnabled(false);
	}
	
	/*
	 * Initialize encoders - set to zero
	 */
	public void initializeEncoders()	{
		frontLeftMotor.getSensorCollection().setQuadraturePosition(0, 0);
		frontRightMotor.getSensorCollection().setQuadraturePosition(0, 0);
		frontRightMotor.setSensorPhase(true);	// runs negative otherwise, due to being mirrored
	}

	/*
	 * Get encoder position
	 * 0 = left side drive rail
	 * 1 = right side drive rail
	 */
	public int getEncoderPosition(int side)	{
		int result;
		
		if(side == 0)	{
			result = frontLeftMotor.getSelectedSensorPosition(0);
		} else if (side == 1)	{
			result = frontRightMotor.getSelectedSensorPosition(0);
		}	else	{	// an illegal value was sent
			result = 0;
		}
		
		return result;
	}

	/*
	 * Get encoder velocity
	 * 0 = left side drive rail
	 * 1 = right side drive rail
	 * 
	 * Talon reports velocity is sensor units per 100ms. 
	 * Current sensor 128 PPR * 4 = 512 counts per revolution
	 */
	public int getEncoderVelocity(int side)	{
		int result;
		
		if(side == 0)	{
			result = frontLeftMotor.getSelectedSensorVelocity(0);
		} else if (side == 1)	{
			result = frontRightMotor.getSelectedSensorVelocity(0);
		}	else	{	// an illegal value was sent
			result = 0;
		}
		
		return result;
	}

	/*
	 * Arcade drive
	 * requires stick number and axis number
	 * 
	 */
	public void arcadeDrive(double speedaxis,  double turnaxis)	{
		diffDrive.arcadeDrive(speedaxis, turnaxis);
	}
	
	/*
	 * Yaw values are in degrees, clockwise increasing positive
	 * 
	 */
	public float imuGetYaw()	{
		return imu.getYaw();
	}
	

	// FIXME
	public void imuZeroYaw()	{
		imu.zeroYaw();		// this is not working, I get a non-zero value even after calling this method
	}

	/*
	 *  Set the brake mode for the drivetrain
	 *  See  Constants.NEUTRAL_COAST and Constants.NEUTRAL_BRAKE 
	 */
	public void setBrakeMode(boolean brakeon)	{
		if (brakeon)	{
			frontRightMotor.setNeutralMode(NeutralMode.Brake);
			frontLeftMotor.setNeutralMode(NeutralMode.Brake);
			rearRightMotor.setNeutralMode(NeutralMode.Brake);
			frontLeftMotor.setNeutralMode(NeutralMode.Brake);
		}	else {
			frontRightMotor.setNeutralMode(NeutralMode.Coast);
			frontLeftMotor.setNeutralMode(NeutralMode.Coast);
			rearRightMotor.setNeutralMode(NeutralMode.Coast);
			frontLeftMotor.setNeutralMode(NeutralMode.Coast);
		}
	}
}
